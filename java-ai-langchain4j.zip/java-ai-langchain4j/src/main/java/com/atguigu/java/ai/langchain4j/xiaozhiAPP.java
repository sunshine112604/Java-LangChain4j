package com.atguigu.java.ai.langchain4j;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.SpringApplication;

@SpringBootApplication
public class xiaozhiAPP {
    public static void main(String[] args) {
        SpringApplication.run(xiaozhiAPP.class,args);
    }
}